
## Week 2

task 1 

see assig2_taks1.pdf

task 2

(a) see attached assig2_taks2ab.pdf

(b) see pdf 

(c) see C and Julia code attached (mainly C file, Julia more for proof of concept)

(d, e) The energy in the higher order method (RK4) should be better conserved. 
However, All our simulations seem quite comparable. The energy is conserved
within 50% for all methods. the RK4 simulation did more loops with the smaller pendulum,
but that appears to be a coincidence. See plots in folder plots.

(f) attached in folder video
