#include <stdio.h>
#include <math.h>
#include "vec_op.h"

#define PI 3.14159265358979

